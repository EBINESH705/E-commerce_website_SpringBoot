package com.smartbuy.controller;

public class AuthController {
}
